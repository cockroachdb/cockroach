UPDATE
  warehouse
SET
  w_ytd = w_ytd + $1:::DECIMAL
WHERE
  w_id = $2:::INT8
RETURNING
  w_name, w_street_1, w_street_2, w_city, w_state, w_zip

-- Arguments:
--  $1: 260.16
--  $2: 803
