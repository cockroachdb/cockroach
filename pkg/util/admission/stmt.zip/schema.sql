CREATE TABLE public.warehouse (
	w_id INT8 NOT NULL,
	w_name VARCHAR(10) NOT NULL,
	w_street_1 VARCHAR(20) NOT NULL,
	w_street_2 VARCHAR(20) NOT NULL,
	w_city VARCHAR(20) NOT NULL,
	w_state CHAR(2) NOT NULL,
	w_zip CHAR(9) NOT NULL,
	w_tax DECIMAL(4,4) NOT NULL,
	w_ytd DECIMAL(12,2) NOT NULL,
	CONSTRAINT warehouse_pkey PRIMARY KEY (w_id ASC)
);
