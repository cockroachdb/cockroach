ALTER TABLE public.warehouse INJECT STATISTICS '[
    {
        "avg_size": 0,
        "columns": [
            "w_id"
        ],
        "created_at": "2022-06-14 22:27:02.5024",
        "distinct_count": 1000,
        "histo_col_type": "",
        "name": "__auto__",
        "null_count": 0,
        "row_count": 1000
    },
    {
        "avg_size": 0,
        "columns": [
            "w_name"
        ],
        "created_at": "2022-06-14 22:27:02.502402",
        "distinct_count": 5,
        "histo_col_type": "",
        "name": "__auto__",
        "null_count": 0,
        "row_count": 1000
    },
    {
        "avg_size": 0,
        "columns": [
            "w_street_1"
        ],
        "created_at": "2022-06-14 22:27:02.502403",
        "distinct_count": 11,
        "histo_col_type": "",
        "name": "__auto__",
        "null_count": 0,
        "row_count": 1000
    },
    {
        "avg_size": 0,
        "columns": [
            "w_street_2"
        ],
        "created_at": "2022-06-14 22:27:02.502403",
        "distinct_count": 11,
        "histo_col_type": "",
        "name": "__auto__",
        "null_count": 0,
        "row_count": 1000
    },
    {
        "avg_size": 0,
        "columns": [
            "w_city"
        ],
        "created_at": "2022-06-14 22:27:02.502404",
        "distinct_count": 11,
        "histo_col_type": "",
        "name": "__auto__",
        "null_count": 0,
        "row_count": 1000
    },
    {
        "avg_size": 0,
        "columns": [
            "w_state"
        ],
        "created_at": "2022-06-14 22:27:02.502405",
        "distinct_count": 522,
        "histo_col_type": "",
        "name": "__auto__",
        "null_count": 0,
        "row_count": 1000
    },
    {
        "avg_size": 0,
        "columns": [
            "w_zip"
        ],
        "created_at": "2022-06-14 22:27:02.502405",
        "distinct_count": 952,
        "histo_col_type": "",
        "name": "__auto__",
        "null_count": 0,
        "row_count": 1000
    },
    {
        "avg_size": 0,
        "columns": [
            "w_tax"
        ],
        "created_at": "2022-06-14 22:27:02.502406",
        "distinct_count": 787,
        "histo_col_type": "",
        "name": "__auto__",
        "null_count": 0,
        "row_count": 1000
    },
    {
        "avg_size": 0,
        "columns": [
            "w_ytd"
        ],
        "created_at": "2022-06-14 22:27:02.502406",
        "distinct_count": 1,
        "histo_col_type": "",
        "name": "__auto__",
        "null_count": 0,
        "row_count": 1000
    },
    {
        "avg_size": 8,
        "columns": [
            "w_ytd"
        ],
        "created_at": "2022-06-15 00:56:44.678481",
        "distinct_count": 1000,
        "histo_buckets": [
            {
                "distinct_range": 0,
                "num_eq": 1,
                "num_range": 0,
                "upper_bound": "4254205.9"
            },
            {
                "distinct_range": 998,
                "num_eq": 1,
                "num_range": 998,
                "upper_bound": "4694883.68"
            }
        ],
        "histo_col_type": "DECIMAL(12,2)",
        "histo_version": 1,
        "name": "__auto__",
        "null_count": 0,
        "row_count": 1000
    },
    {
        "avg_size": 4,
        "columns": [
            "w_name"
        ],
        "created_at": "2022-06-15 00:56:44.678481",
        "distinct_count": 5,
        "histo_buckets": [
            {
                "distinct_range": 0,
                "num_eq": 192,
                "num_range": 0,
                "upper_bound": "10"
            },
            {
                "distinct_range": 3,
                "num_eq": 193,
                "num_range": 615,
                "upper_bound": "9"
            }
        ],
        "histo_col_type": "VARCHAR(10)",
        "histo_version": 1,
        "name": "__auto__",
        "null_count": 0,
        "row_count": 1000
    },
    {
        "avg_size": 4,
        "columns": [
            "w_street_1"
        ],
        "created_at": "2022-06-15 00:56:44.678481",
        "distinct_count": 11,
        "histo_buckets": [
            {
                "distinct_range": 0,
                "num_eq": 89,
                "num_range": 0,
                "upper_bound": "10"
            },
            {
                "distinct_range": 9,
                "num_eq": 101,
                "num_range": 810,
                "upper_bound": "20"
            }
        ],
        "histo_col_type": "VARCHAR(20)",
        "histo_version": 1,
        "name": "__auto__",
        "null_count": 0,
        "row_count": 1000
    },
    {
        "avg_size": 4,
        "columns": [
            "w_street_2"
        ],
        "created_at": "2022-06-15 00:56:44.678481",
        "distinct_count": 11,
        "histo_buckets": [
            {
                "distinct_range": 0,
                "num_eq": 90,
                "num_range": 0,
                "upper_bound": "10"
            },
            {
                "distinct_range": 9,
                "num_eq": 88,
                "num_range": 822,
                "upper_bound": "20"
            }
        ],
        "histo_col_type": "VARCHAR(20)",
        "histo_version": 1,
        "name": "__auto__",
        "null_count": 0,
        "row_count": 1000
    },
    {
        "avg_size": 3,
        "columns": [
            "w_id"
        ],
        "created_at": "2022-06-15 00:56:44.678481",
        "distinct_count": 1000,
        "histo_buckets": [
            {
                "distinct_range": 0,
                "num_eq": 1,
                "num_range": 0,
                "upper_bound": "0"
            },
            {
                "distinct_range": 4,
                "num_eq": 1,
                "num_range": 4,
                "upper_bound": "5"
            },
            {
                "distinct_range": 4,
                "num_eq": 1,
                "num_range": 4,
                "upper_bound": "10"
            },
            {
                "distinct_range": 4,
                "num_eq": 1,
                "num_range": 4,
                "upper_bound": "15"
            },
            {
                "distinct_range": 4,
                "num_eq": 1,
                "num_range": 4,
                "upper_bound": "20"
            },
            {
                "distinct_range": 4,
                "num_eq": 1,
                "num_range": 4,
                "upper_bound": "25"
            },
            {
                "distinct_range": 4,
                "num_eq": 1,
                "num_range": 4,
                "upper_bound": "30"
            },
            {
                "distinct_range": 4,
                "num_eq": 1,
                "num_range": 4,
                "upper_bound": "35"
            },
            {
                "distinct_range": 4,
                "num_eq": 1,
                "num_range": 4,
                "upper_bound": "40"
            },
            {
                "distinct_range": 4,
                "num_eq": 1,
                "num_range": 4,
                "upper_bound": "45"
            },
            {
                "distinct_range": 4,
                "num_eq": 1,
                "num_range": 4,
                "upper_bound": "50"
            },
            {
                "distinct_range": 4,
                "num_eq": 1,
                "num_range": 4,
                "upper_bound": "55"
            },
            {
                "distinct_range": 4,
                "num_eq": 1,
                "num_range": 4,
                "upper_bound": "60"
            },
            {
                "distinct_range": 4,
                "num_eq": 1,
                "num_range": 4,
                "upper_bound": "65"
            },
            {
                "distinct_range": 4,
                "num_eq": 1,
                "num_range": 4,
                "upper_bound": "70"
            },
            {
                "distinct_range": 4,
                "num_eq": 1,
                "num_range": 4,
                "upper_bound": "75"
            },
            {
                "distinct_range": 4,
                "num_eq": 1,
                "num_range": 4,
                "upper_bound": "80"
            },
            {
                "distinct_range": 4,
                "num_eq": 1,
                "num_range": 4,
                "upper_bound": "85"
            },
            {
                "distinct_range": 4,
                "num_eq": 1,
                "num_range": 4,
                "upper_bound": "90"
            },
            {
                "distinct_range": 4,
                "num_eq": 1,
                "num_range": 4,
                "upper_bound": "95"
            },
            {
                "distinct_range": 4,
                "num_eq": 1,
                "num_range": 4,
                "upper_bound": "100"
            },
            {
                "distinct_range": 4,
                "num_eq": 1,
                "num_range": 4,
                "upper_bound": "105"
            },
            {
                "distinct_range": 4,
                "num_eq": 1,
                "num_range": 4,
                "upper_bound": "110"
            },
            {
                "distinct_range": 4,
                "num_eq": 1,
                "num_range": 4,
                "upper_bound": "115"
            },
            {
                "distinct_range": 4,
                "num_eq": 1,
                "num_range": 4,
                "upper_bound": "120"
            },
            {
                "distinct_range": 4,
                "num_eq": 1,
                "num_range": 4,
                "upper_bound": "125"
            },
            {
                "distinct_range": 4,
                "num_eq": 1,
                "num_range": 4,
                "upper_bound": "130"
            },
            {
                "distinct_range": 4,
                "num_eq": 1,
                "num_range": 4,
                "upper_bound": "135"
            },
            {
                "distinct_range": 4,
                "num_eq": 1,
                "num_range": 4,
                "upper_bound": "140"
            },
            {
                "distinct_range": 4,
                "num_eq": 1,
                "num_range": 4,
                "upper_bound": "145"
            },
            {
                "distinct_range": 4,
                "num_eq": 1,
                "num_range": 4,
                "upper_bound": "150"
            },
            {
                "distinct_range": 4,
                "num_eq": 1,
                "num_range": 4,
                "upper_bound": "155"
            },
            {
                "distinct_range": 4,
                "num_eq": 1,
                "num_range": 4,
                "upper_bound": "160"
            },
            {
                "distinct_range": 4,
                "num_eq": 1,
                "num_range": 4,
                "upper_bound": "165"
            },
            {
                "distinct_range": 4,
                "num_eq": 1,
                "num_range": 4,
                "upper_bound": "170"
            },
            {
                "distinct_range": 4,
                "num_eq": 1,
                "num_range": 4,
                "upper_bound": "175"
            },
            {
                "distinct_range": 4,
                "num_eq": 1,
                "num_range": 4,
                "upper_bound": "180"
            },
            {
                "distinct_range": 4,
                "num_eq": 1,
                "num_range": 4,
                "upper_bound": "185"
            },
            {
                "distinct_range": 4,
                "num_eq": 1,
                "num_range": 4,
                "upper_bound": "190"
            },
            {
                "distinct_range": 4,
                "num_eq": 1,
                "num_range": 4,
                "upper_bound": "195"
            },
            {
                "distinct_range": 4,
                "num_eq": 1,
                "num_range": 4,
                "upper_bound": "200"
            },
            {
                "distinct_range": 4,
                "num_eq": 1,
                "num_range": 4,
                "upper_bound": "205"
            },
            {
                "distinct_range": 4,
                "num_eq": 1,
                "num_range": 4,
                "upper_bound": "210"
            },
            {
                "distinct_range": 4,
                "num_eq": 1,
                "num_range": 4,
                "upper_bound": "215"
            },
            {
                "distinct_range": 4,
                "num_eq": 1,
                "num_range": 4,
                "upper_bound": "220"
            },
            {
                "distinct_range": 4,
                "num_eq": 1,
                "num_range": 4,
                "upper_bound": "225"
            },
            {
                "distinct_range": 4,
                "num_eq": 1,
                "num_range": 4,
                "upper_bound": "230"
            },
            {
                "distinct_range": 4,
                "num_eq": 1,
                "num_range": 4,
                "upper_bound": "235"
            },
            {
                "distinct_range": 4,
                "num_eq": 1,
                "num_range": 4,
                "upper_bound": "240"
            },
            {
                "distinct_range": 4,
                "num_eq": 1,
                "num_range": 4,
                "upper_bound": "245"
            },
            {
                "distinct_range": 4,
                "num_eq": 1,
                "num_range": 4,
                "upper_bound": "250"
            },
            {
                "distinct_range": 4,
                "num_eq": 1,
                "num_range": 4,
                "upper_bound": "255"
            },
            {
                "distinct_range": 4,
                "num_eq": 1,
                "num_range": 4,
                "upper_bound": "260"
            },
            {
                "distinct_range": 4,
                "num_eq": 1,
                "num_range": 4,
                "upper_bound": "265"
            },
            {
                "distinct_range": 4,
                "num_eq": 1,
                "num_range": 4,
                "upper_bound": "270"
            },
            {
                "distinct_range": 4,
                "num_eq": 1,
                "num_range": 4,
                "upper_bound": "275"
            },
            {
                "distinct_range": 4,
                "num_eq": 1,
                "num_range": 4,
                "upper_bound": "280"
            },
            {
                "distinct_range": 4,
                "num_eq": 1,
                "num_range": 4,
                "upper_bound": "285"
            },
            {
                "distinct_range": 4,
                "num_eq": 1,
                "num_range": 4,
                "upper_bound": "290"
            },
            {
                "distinct_range": 4,
                "num_eq": 1,
                "num_range": 4,
                "upper_bound": "295"
            },
            {
                "distinct_range": 4,
                "num_eq": 1,
                "num_range": 4,
                "upper_bound": "300"
            },
            {
                "distinct_range": 4,
                "num_eq": 1,
                "num_range": 4,
                "upper_bound": "305"
            },
            {
                "distinct_range": 4,
                "num_eq": 1,
                "num_range": 4,
                "upper_bound": "310"
            },
            {
                "distinct_range": 4,
                "num_eq": 1,
                "num_range": 4,
                "upper_bound": "315"
            },
            {
                "distinct_range": 4,
                "num_eq": 1,
                "num_range": 4,
                "upper_bound": "320"
            },
            {
                "distinct_range": 4,
                "num_eq": 1,
                "num_range": 4,
                "upper_bound": "325"
            },
            {
                "distinct_range": 4,
                "num_eq": 1,
                "num_range": 4,
                "upper_bound": "330"
            },
            {
                "distinct_range": 4,
                "num_eq": 1,
                "num_range": 4,
                "upper_bound": "335"
            },
            {
                "distinct_range": 4,
                "num_eq": 1,
                "num_range": 4,
                "upper_bound": "340"
            },
            {
                "distinct_range": 4,
                "num_eq": 1,
                "num_range": 4,
                "upper_bound": "345"
            },
            {
                "distinct_range": 4,
                "num_eq": 1,
                "num_range": 4,
                "upper_bound": "350"
            },
            {
                "distinct_range": 4,
                "num_eq": 1,
                "num_range": 4,
                "upper_bound": "355"
            },
            {
                "distinct_range": 4,
                "num_eq": 1,
                "num_range": 4,
                "upper_bound": "360"
            },
            {
                "distinct_range": 4,
                "num_eq": 1,
                "num_range": 4,
                "upper_bound": "365"
            },
            {
                "distinct_range": 4,
                "num_eq": 1,
                "num_range": 4,
                "upper_bound": "370"
            },
            {
                "distinct_range": 4,
                "num_eq": 1,
                "num_range": 4,
                "upper_bound": "375"
            },
            {
                "distinct_range": 4,
                "num_eq": 1,
                "num_range": 4,
                "upper_bound": "380"
            },
            {
                "distinct_range": 4,
                "num_eq": 1,
                "num_range": 4,
                "upper_bound": "385"
            },
            {
                "distinct_range": 4,
                "num_eq": 1,
                "num_range": 4,
                "upper_bound": "390"
            },
            {
                "distinct_range": 4,
                "num_eq": 1,
                "num_range": 4,
                "upper_bound": "395"
            },
            {
                "distinct_range": 4,
                "num_eq": 1,
                "num_range": 4,
                "upper_bound": "400"
            },
            {
                "distinct_range": 4,
                "num_eq": 1,
                "num_range": 4,
                "upper_bound": "405"
            },
            {
                "distinct_range": 4,
                "num_eq": 1,
                "num_range": 4,
                "upper_bound": "410"
            },
            {
                "distinct_range": 4,
                "num_eq": 1,
                "num_range": 4,
                "upper_bound": "415"
            },
            {
                "distinct_range": 4,
                "num_eq": 1,
                "num_range": 4,
                "upper_bound": "420"
            },
            {
                "distinct_range": 4,
                "num_eq": 1,
                "num_range": 4,
                "upper_bound": "425"
            },
            {
                "distinct_range": 4,
                "num_eq": 1,
                "num_range": 4,
                "upper_bound": "430"
            },
            {
                "distinct_range": 4,
                "num_eq": 1,
                "num_range": 4,
                "upper_bound": "435"
            },
            {
                "distinct_range": 4,
                "num_eq": 1,
                "num_range": 4,
                "upper_bound": "440"
            },
            {
                "distinct_range": 4,
                "num_eq": 1,
                "num_range": 4,
                "upper_bound": "445"
            },
            {
                "distinct_range": 4,
                "num_eq": 1,
                "num_range": 4,
                "upper_bound": "450"
            },
            {
                "distinct_range": 4,
                "num_eq": 1,
                "num_range": 4,
                "upper_bound": "455"
            },
            {
                "distinct_range": 4,
                "num_eq": 1,
                "num_range": 4,
                "upper_bound": "460"
            },
            {
                "distinct_range": 4,
                "num_eq": 1,
                "num_range": 4,
                "upper_bound": "465"
            },
            {
                "distinct_range": 4,
                "num_eq": 1,
                "num_range": 4,
                "upper_bound": "470"
            },
            {
                "distinct_range": 4,
                "num_eq": 1,
                "num_range": 4,
                "upper_bound": "475"
            },
            {
                "distinct_range": 4,
                "num_eq": 1,
                "num_range": 4,
                "upper_bound": "480"
            },
            {
                "distinct_range": 4,
                "num_eq": 1,
                "num_range": 4,
                "upper_bound": "485"
            },
            {
                "distinct_range": 4,
                "num_eq": 1,
                "num_range": 4,
                "upper_bound": "490"
            },
            {
                "distinct_range": 4,
                "num_eq": 1,
                "num_range": 4,
                "upper_bound": "495"
            },
            {
                "distinct_range": 4,
                "num_eq": 1,
                "num_range": 4,
                "upper_bound": "500"
            },
            {
                "distinct_range": 4,
                "num_eq": 1,
                "num_range": 4,
                "upper_bound": "505"
            },
            {
                "distinct_range": 4,
                "num_eq": 1,
                "num_range": 4,
                "upper_bound": "510"
            },
            {
                "distinct_range": 4,
                "num_eq": 1,
                "num_range": 4,
                "upper_bound": "515"
            },
            {
                "distinct_range": 4,
                "num_eq": 1,
                "num_range": 4,
                "upper_bound": "520"
            },
            {
                "distinct_range": 4,
                "num_eq": 1,
                "num_range": 4,
                "upper_bound": "525"
            },
            {
                "distinct_range": 4,
                "num_eq": 1,
                "num_range": 4,
                "upper_bound": "530"
            },
            {
                "distinct_range": 4,
                "num_eq": 1,
                "num_range": 4,
                "upper_bound": "535"
            },
            {
                "distinct_range": 4,
                "num_eq": 1,
                "num_range": 4,
                "upper_bound": "540"
            },
            {
                "distinct_range": 4,
                "num_eq": 1,
                "num_range": 4,
                "upper_bound": "545"
            },
            {
                "distinct_range": 4,
                "num_eq": 1,
                "num_range": 4,
                "upper_bound": "550"
            },
            {
                "distinct_range": 4,
                "num_eq": 1,
                "num_range": 4,
                "upper_bound": "555"
            },
            {
                "distinct_range": 4,
                "num_eq": 1,
                "num_range": 4,
                "upper_bound": "560"
            },
            {
                "distinct_range": 4,
                "num_eq": 1,
                "num_range": 4,
                "upper_bound": "565"
            },
            {
                "distinct_range": 4,
                "num_eq": 1,
                "num_range": 4,
                "upper_bound": "570"
            },
            {
                "distinct_range": 4,
                "num_eq": 1,
                "num_range": 4,
                "upper_bound": "575"
            },
            {
                "distinct_range": 4,
                "num_eq": 1,
                "num_range": 4,
                "upper_bound": "580"
            },
            {
                "distinct_range": 4,
                "num_eq": 1,
                "num_range": 4,
                "upper_bound": "585"
            },
            {
                "distinct_range": 4,
                "num_eq": 1,
                "num_range": 4,
                "upper_bound": "590"
            },
            {
                "distinct_range": 4,
                "num_eq": 1,
                "num_range": 4,
                "upper_bound": "595"
            },
            {
                "distinct_range": 4,
                "num_eq": 1,
                "num_range": 4,
                "upper_bound": "600"
            },
            {
                "distinct_range": 4,
                "num_eq": 1,
                "num_range": 4,
                "upper_bound": "605"
            },
            {
                "distinct_range": 4,
                "num_eq": 1,
                "num_range": 4,
                "upper_bound": "610"
            },
            {
                "distinct_range": 4,
                "num_eq": 1,
                "num_range": 4,
                "upper_bound": "615"
            },
            {
                "distinct_range": 4,
                "num_eq": 1,
                "num_range": 4,
                "upper_bound": "620"
            },
            {
                "distinct_range": 4,
                "num_eq": 1,
                "num_range": 4,
                "upper_bound": "625"
            },
            {
                "distinct_range": 4,
                "num_eq": 1,
                "num_range": 4,
                "upper_bound": "630"
            },
            {
                "distinct_range": 4,
                "num_eq": 1,
                "num_range": 4,
                "upper_bound": "635"
            },
            {
                "distinct_range": 4,
                "num_eq": 1,
                "num_range": 4,
                "upper_bound": "640"
            },
            {
                "distinct_range": 4,
                "num_eq": 1,
                "num_range": 4,
                "upper_bound": "645"
            },
            {
                "distinct_range": 4,
                "num_eq": 1,
                "num_range": 4,
                "upper_bound": "650"
            },
            {
                "distinct_range": 4,
                "num_eq": 1,
                "num_range": 4,
                "upper_bound": "655"
            },
            {
                "distinct_range": 4,
                "num_eq": 1,
                "num_range": 4,
                "upper_bound": "660"
            },
            {
                "distinct_range": 4,
                "num_eq": 1,
                "num_range": 4,
                "upper_bound": "665"
            },
            {
                "distinct_range": 4,
                "num_eq": 1,
                "num_range": 4,
                "upper_bound": "670"
            },
            {
                "distinct_range": 4,
                "num_eq": 1,
                "num_range": 4,
                "upper_bound": "675"
            },
            {
                "distinct_range": 4,
                "num_eq": 1,
                "num_range": 4,
                "upper_bound": "680"
            },
            {
                "distinct_range": 4,
                "num_eq": 1,
                "num_range": 4,
                "upper_bound": "685"
            },
            {
                "distinct_range": 4,
                "num_eq": 1,
                "num_range": 4,
                "upper_bound": "690"
            },
            {
                "distinct_range": 4,
                "num_eq": 1,
                "num_range": 4,
                "upper_bound": "695"
            },
            {
                "distinct_range": 4,
                "num_eq": 1,
                "num_range": 4,
                "upper_bound": "700"
            },
            {
                "distinct_range": 4,
                "num_eq": 1,
                "num_range": 4,
                "upper_bound": "705"
            },
            {
                "distinct_range": 4,
                "num_eq": 1,
                "num_range": 4,
                "upper_bound": "710"
            },
            {
                "distinct_range": 4,
                "num_eq": 1,
                "num_range": 4,
                "upper_bound": "715"
            },
            {
                "distinct_range": 4,
                "num_eq": 1,
                "num_range": 4,
                "upper_bound": "720"
            },
            {
                "distinct_range": 4,
                "num_eq": 1,
                "num_range": 4,
                "upper_bound": "725"
            },
            {
                "distinct_range": 4,
                "num_eq": 1,
                "num_range": 4,
                "upper_bound": "730"
            },
            {
                "distinct_range": 4,
                "num_eq": 1,
                "num_range": 4,
                "upper_bound": "735"
            },
            {
                "distinct_range": 4,
                "num_eq": 1,
                "num_range": 4,
                "upper_bound": "740"
            },
            {
                "distinct_range": 4,
                "num_eq": 1,
                "num_range": 4,
                "upper_bound": "745"
            },
            {
                "distinct_range": 4,
                "num_eq": 1,
                "num_range": 4,
                "upper_bound": "750"
            },
            {
                "distinct_range": 4,
                "num_eq": 1,
                "num_range": 4,
                "upper_bound": "755"
            },
            {
                "distinct_range": 4,
                "num_eq": 1,
                "num_range": 4,
                "upper_bound": "760"
            },
            {
                "distinct_range": 4,
                "num_eq": 1,
                "num_range": 4,
                "upper_bound": "765"
            },
            {
                "distinct_range": 4,
                "num_eq": 1,
                "num_range": 4,
                "upper_bound": "770"
            },
            {
                "distinct_range": 4,
                "num_eq": 1,
                "num_range": 4,
                "upper_bound": "775"
            },
            {
                "distinct_range": 4,
                "num_eq": 1,
                "num_range": 4,
                "upper_bound": "780"
            },
            {
                "distinct_range": 4,
                "num_eq": 1,
                "num_range": 4,
                "upper_bound": "785"
            },
            {
                "distinct_range": 4,
                "num_eq": 1,
                "num_range": 4,
                "upper_bound": "790"
            },
            {
                "distinct_range": 4,
                "num_eq": 1,
                "num_range": 4,
                "upper_bound": "795"
            },
            {
                "distinct_range": 4,
                "num_eq": 1,
                "num_range": 4,
                "upper_bound": "800"
            },
            {
                "distinct_range": 4,
                "num_eq": 1,
                "num_range": 4,
                "upper_bound": "805"
            },
            {
                "distinct_range": 4,
                "num_eq": 1,
                "num_range": 4,
                "upper_bound": "810"
            },
            {
                "distinct_range": 4,
                "num_eq": 1,
                "num_range": 4,
                "upper_bound": "815"
            },
            {
                "distinct_range": 4,
                "num_eq": 1,
                "num_range": 4,
                "upper_bound": "820"
            },
            {
                "distinct_range": 4,
                "num_eq": 1,
                "num_range": 4,
                "upper_bound": "825"
            },
            {
                "distinct_range": 4,
                "num_eq": 1,
                "num_range": 4,
                "upper_bound": "830"
            },
            {
                "distinct_range": 4,
                "num_eq": 1,
                "num_range": 4,
                "upper_bound": "835"
            },
            {
                "distinct_range": 4,
                "num_eq": 1,
                "num_range": 4,
                "upper_bound": "840"
            },
            {
                "distinct_range": 4,
                "num_eq": 1,
                "num_range": 4,
                "upper_bound": "845"
            },
            {
                "distinct_range": 4,
                "num_eq": 1,
                "num_range": 4,
                "upper_bound": "850"
            },
            {
                "distinct_range": 4,
                "num_eq": 1,
                "num_range": 4,
                "upper_bound": "855"
            },
            {
                "distinct_range": 4,
                "num_eq": 1,
                "num_range": 4,
                "upper_bound": "860"
            },
            {
                "distinct_range": 4,
                "num_eq": 1,
                "num_range": 4,
                "upper_bound": "865"
            },
            {
                "distinct_range": 4,
                "num_eq": 1,
                "num_range": 4,
                "upper_bound": "870"
            },
            {
                "distinct_range": 4,
                "num_eq": 1,
                "num_range": 4,
                "upper_bound": "875"
            },
            {
                "distinct_range": 4,
                "num_eq": 1,
                "num_range": 4,
                "upper_bound": "880"
            },
            {
                "distinct_range": 4,
                "num_eq": 1,
                "num_range": 4,
                "upper_bound": "885"
            },
            {
                "distinct_range": 4,
                "num_eq": 1,
                "num_range": 4,
                "upper_bound": "890"
            },
            {
                "distinct_range": 4,
                "num_eq": 1,
                "num_range": 4,
                "upper_bound": "895"
            },
            {
                "distinct_range": 4,
                "num_eq": 1,
                "num_range": 4,
                "upper_bound": "900"
            },
            {
                "distinct_range": 4,
                "num_eq": 1,
                "num_range": 4,
                "upper_bound": "905"
            },
            {
                "distinct_range": 4,
                "num_eq": 1,
                "num_range": 4,
                "upper_bound": "910"
            },
            {
                "distinct_range": 4,
                "num_eq": 1,
                "num_range": 4,
                "upper_bound": "915"
            },
            {
                "distinct_range": 4,
                "num_eq": 1,
                "num_range": 4,
                "upper_bound": "920"
            },
            {
                "distinct_range": 4,
                "num_eq": 1,
                "num_range": 4,
                "upper_bound": "925"
            },
            {
                "distinct_range": 4,
                "num_eq": 1,
                "num_range": 4,
                "upper_bound": "930"
            },
            {
                "distinct_range": 4,
                "num_eq": 1,
                "num_range": 4,
                "upper_bound": "935"
            },
            {
                "distinct_range": 4,
                "num_eq": 1,
                "num_range": 4,
                "upper_bound": "940"
            },
            {
                "distinct_range": 4,
                "num_eq": 1,
                "num_range": 4,
                "upper_bound": "945"
            },
            {
                "distinct_range": 4,
                "num_eq": 1,
                "num_range": 4,
                "upper_bound": "950"
            },
            {
                "distinct_range": 4,
                "num_eq": 1,
                "num_range": 4,
                "upper_bound": "955"
            },
            {
                "distinct_range": 4,
                "num_eq": 1,
                "num_range": 4,
                "upper_bound": "960"
            },
            {
                "distinct_range": 4,
                "num_eq": 1,
                "num_range": 4,
                "upper_bound": "965"
            },
            {
                "distinct_range": 4,
                "num_eq": 1,
                "num_range": 4,
                "upper_bound": "970"
            },
            {
                "distinct_range": 4,
                "num_eq": 1,
                "num_range": 4,
                "upper_bound": "975"
            },
            {
                "distinct_range": 5,
                "num_eq": 1,
                "num_range": 5,
                "upper_bound": "981"
            },
            {
                "distinct_range": 5,
                "num_eq": 1,
                "num_range": 5,
                "upper_bound": "987"
            },
            {
                "distinct_range": 5,
                "num_eq": 1,
                "num_range": 5,
                "upper_bound": "993"
            },
            {
                "distinct_range": 5,
                "num_eq": 1,
                "num_range": 5,
                "upper_bound": "999"
            }
        ],
        "histo_col_type": "INT8",
        "histo_version": 1,
        "name": "__auto__",
        "null_count": 0,
        "row_count": 1000
    },
    {
        "avg_size": 4,
        "columns": [
            "w_state"
        ],
        "created_at": "2022-06-15 00:56:44.678481",
        "distinct_count": 26,
        "histo_buckets": [
            {
                "distinct_range": 0,
                "num_eq": 41,
                "num_range": 0,
                "upper_bound": "AK"
            },
            {
                "distinct_range": 24,
                "num_eq": 38,
                "num_range": 921,
                "upper_bound": "ZT"
            }
        ],
        "histo_col_type": "CHAR(2)",
        "histo_version": 1,
        "name": "__auto__",
        "null_count": 0,
        "row_count": 1000
    },
    {
        "avg_size": 11,
        "columns": [
            "w_zip"
        ],
        "created_at": "2022-06-15 00:56:44.678481",
        "distinct_count": 10,
        "histo_buckets": [
            {
                "distinct_range": 0,
                "num_eq": 106,
                "num_range": 0,
                "upper_bound": "022311111"
            },
            {
                "distinct_range": 8,
                "num_eq": 99,
                "num_range": 795,
                "upper_bound": "902211111"
            }
        ],
        "histo_col_type": "CHAR(9)",
        "histo_version": 1,
        "name": "__auto__",
        "null_count": 0,
        "row_count": 1000
    },
    {
        "avg_size": 6,
        "columns": [
            "w_tax"
        ],
        "created_at": "2022-06-15 00:56:44.678481",
        "distinct_count": 771,
        "histo_buckets": [
            {
                "distinct_range": 0,
                "num_eq": 1,
                "num_range": 0,
                "upper_bound": "0"
            },
            {
                "distinct_range": 769,
                "num_eq": 2,
                "num_range": 997,
                "upper_bound": "0.1999"
            }
        ],
        "histo_col_type": "DECIMAL(4,4)",
        "histo_version": 1,
        "name": "__auto__",
        "null_count": 0,
        "row_count": 1000
    },
    {
        "avg_size": 4,
        "columns": [
            "w_city"
        ],
        "created_at": "2022-06-15 00:56:44.678481",
        "distinct_count": 11,
        "histo_buckets": [
            {
                "distinct_range": 0,
                "num_eq": 81,
                "num_range": 0,
                "upper_bound": "10"
            },
            {
                "distinct_range": 9,
                "num_eq": 104,
                "num_range": 815,
                "upper_bound": "20"
            }
        ],
        "histo_col_type": "VARCHAR(20)",
        "histo_version": 1,
        "name": "__auto__",
        "null_count": 0,
        "row_count": 1000
    },
    {
        "avg_size": 3,
        "columns": [
            "w_id"
        ],
        "created_at": "2022-06-15 01:45:57.80267",
        "distinct_count": 1000,
        "histo_buckets": [
            {
                "distinct_range": 0,
                "num_eq": 1,
                "num_range": 0,
                "upper_bound": "0"
            },
            {
                "distinct_range": 4,
                "num_eq": 1,
                "num_range": 4,
                "upper_bound": "5"
            },
            {
                "distinct_range": 4,
                "num_eq": 1,
                "num_range": 4,
                "upper_bound": "10"
            },
            {
                "distinct_range": 4,
                "num_eq": 1,
                "num_range": 4,
                "upper_bound": "15"
            },
            {
                "distinct_range": 4,
                "num_eq": 1,
                "num_range": 4,
                "upper_bound": "20"
            },
            {
                "distinct_range": 4,
                "num_eq": 1,
                "num_range": 4,
                "upper_bound": "25"
            },
            {
                "distinct_range": 4,
                "num_eq": 1,
                "num_range": 4,
                "upper_bound": "30"
            },
            {
                "distinct_range": 4,
                "num_eq": 1,
                "num_range": 4,
                "upper_bound": "35"
            },
            {
                "distinct_range": 4,
                "num_eq": 1,
                "num_range": 4,
                "upper_bound": "40"
            },
            {
                "distinct_range": 4,
                "num_eq": 1,
                "num_range": 4,
                "upper_bound": "45"
            },
            {
                "distinct_range": 4,
                "num_eq": 1,
                "num_range": 4,
                "upper_bound": "50"
            },
            {
                "distinct_range": 4,
                "num_eq": 1,
                "num_range": 4,
                "upper_bound": "55"
            },
            {
                "distinct_range": 4,
                "num_eq": 1,
                "num_range": 4,
                "upper_bound": "60"
            },
            {
                "distinct_range": 4,
                "num_eq": 1,
                "num_range": 4,
                "upper_bound": "65"
            },
            {
                "distinct_range": 4,
                "num_eq": 1,
                "num_range": 4,
                "upper_bound": "70"
            },
            {
                "distinct_range": 4,
                "num_eq": 1,
                "num_range": 4,
                "upper_bound": "75"
            },
            {
                "distinct_range": 4,
                "num_eq": 1,
                "num_range": 4,
                "upper_bound": "80"
            },
            {
                "distinct_range": 4,
                "num_eq": 1,
                "num_range": 4,
                "upper_bound": "85"
            },
            {
                "distinct_range": 4,
                "num_eq": 1,
                "num_range": 4,
                "upper_bound": "90"
            },
            {
                "distinct_range": 4,
                "num_eq": 1,
                "num_range": 4,
                "upper_bound": "95"
            },
            {
                "distinct_range": 4,
                "num_eq": 1,
                "num_range": 4,
                "upper_bound": "100"
            },
            {
                "distinct_range": 4,
                "num_eq": 1,
                "num_range": 4,
                "upper_bound": "105"
            },
            {
                "distinct_range": 4,
                "num_eq": 1,
                "num_range": 4,
                "upper_bound": "110"
            },
            {
                "distinct_range": 4,
                "num_eq": 1,
                "num_range": 4,
                "upper_bound": "115"
            },
            {
                "distinct_range": 4,
                "num_eq": 1,
                "num_range": 4,
                "upper_bound": "120"
            },
            {
                "distinct_range": 4,
                "num_eq": 1,
                "num_range": 4,
                "upper_bound": "125"
            },
            {
                "distinct_range": 4,
                "num_eq": 1,
                "num_range": 4,
                "upper_bound": "130"
            },
            {
                "distinct_range": 4,
                "num_eq": 1,
                "num_range": 4,
                "upper_bound": "135"
            },
            {
                "distinct_range": 4,
                "num_eq": 1,
                "num_range": 4,
                "upper_bound": "140"
            },
            {
                "distinct_range": 4,
                "num_eq": 1,
                "num_range": 4,
                "upper_bound": "145"
            },
            {
                "distinct_range": 4,
                "num_eq": 1,
                "num_range": 4,
                "upper_bound": "150"
            },
            {
                "distinct_range": 4,
                "num_eq": 1,
                "num_range": 4,
                "upper_bound": "155"
            },
            {
                "distinct_range": 4,
                "num_eq": 1,
                "num_range": 4,
                "upper_bound": "160"
            },
            {
                "distinct_range": 4,
                "num_eq": 1,
                "num_range": 4,
                "upper_bound": "165"
            },
            {
                "distinct_range": 4,
                "num_eq": 1,
                "num_range": 4,
                "upper_bound": "170"
            },
            {
                "distinct_range": 4,
                "num_eq": 1,
                "num_range": 4,
                "upper_bound": "175"
            },
            {
                "distinct_range": 4,
                "num_eq": 1,
                "num_range": 4,
                "upper_bound": "180"
            },
            {
                "distinct_range": 4,
                "num_eq": 1,
                "num_range": 4,
                "upper_bound": "185"
            },
            {
                "distinct_range": 4,
                "num_eq": 1,
                "num_range": 4,
                "upper_bound": "190"
            },
            {
                "distinct_range": 4,
                "num_eq": 1,
                "num_range": 4,
                "upper_bound": "195"
            },
            {
                "distinct_range": 4,
                "num_eq": 1,
                "num_range": 4,
                "upper_bound": "200"
            },
            {
                "distinct_range": 4,
                "num_eq": 1,
                "num_range": 4,
                "upper_bound": "205"
            },
            {
                "distinct_range": 4,
                "num_eq": 1,
                "num_range": 4,
                "upper_bound": "210"
            },
            {
                "distinct_range": 4,
                "num_eq": 1,
                "num_range": 4,
                "upper_bound": "215"
            },
            {
                "distinct_range": 4,
                "num_eq": 1,
                "num_range": 4,
                "upper_bound": "220"
            },
            {
                "distinct_range": 4,
                "num_eq": 1,
                "num_range": 4,
                "upper_bound": "225"
            },
            {
                "distinct_range": 4,
                "num_eq": 1,
                "num_range": 4,
                "upper_bound": "230"
            },
            {
                "distinct_range": 4,
                "num_eq": 1,
                "num_range": 4,
                "upper_bound": "235"
            },
            {
                "distinct_range": 4,
                "num_eq": 1,
                "num_range": 4,
                "upper_bound": "240"
            },
            {
                "distinct_range": 4,
                "num_eq": 1,
                "num_range": 4,
                "upper_bound": "245"
            },
            {
                "distinct_range": 4,
                "num_eq": 1,
                "num_range": 4,
                "upper_bound": "250"
            },
            {
                "distinct_range": 4,
                "num_eq": 1,
                "num_range": 4,
                "upper_bound": "255"
            },
            {
                "distinct_range": 4,
                "num_eq": 1,
                "num_range": 4,
                "upper_bound": "260"
            },
            {
                "distinct_range": 4,
                "num_eq": 1,
                "num_range": 4,
                "upper_bound": "265"
            },
            {
                "distinct_range": 4,
                "num_eq": 1,
                "num_range": 4,
                "upper_bound": "270"
            },
            {
                "distinct_range": 4,
                "num_eq": 1,
                "num_range": 4,
                "upper_bound": "275"
            },
            {
                "distinct_range": 4,
                "num_eq": 1,
                "num_range": 4,
                "upper_bound": "280"
            },
            {
                "distinct_range": 4,
                "num_eq": 1,
                "num_range": 4,
                "upper_bound": "285"
            },
            {
                "distinct_range": 4,
                "num_eq": 1,
                "num_range": 4,
                "upper_bound": "290"
            },
            {
                "distinct_range": 4,
                "num_eq": 1,
                "num_range": 4,
                "upper_bound": "295"
            },
            {
                "distinct_range": 4,
                "num_eq": 1,
                "num_range": 4,
                "upper_bound": "300"
            },
            {
                "distinct_range": 4,
                "num_eq": 1,
                "num_range": 4,
                "upper_bound": "305"
            },
            {
                "distinct_range": 4,
                "num_eq": 1,
                "num_range": 4,
                "upper_bound": "310"
            },
            {
                "distinct_range": 4,
                "num_eq": 1,
                "num_range": 4,
                "upper_bound": "315"
            },
            {
                "distinct_range": 4,
                "num_eq": 1,
                "num_range": 4,
                "upper_bound": "320"
            },
            {
                "distinct_range": 4,
                "num_eq": 1,
                "num_range": 4,
                "upper_bound": "325"
            },
            {
                "distinct_range": 4,
                "num_eq": 1,
                "num_range": 4,
                "upper_bound": "330"
            },
            {
                "distinct_range": 4,
                "num_eq": 1,
                "num_range": 4,
                "upper_bound": "335"
            },
            {
                "distinct_range": 4,
                "num_eq": 1,
                "num_range": 4,
                "upper_bound": "340"
            },
            {
                "distinct_range": 4,
                "num_eq": 1,
                "num_range": 4,
                "upper_bound": "345"
            },
            {
                "distinct_range": 4,
                "num_eq": 1,
                "num_range": 4,
                "upper_bound": "350"
            },
            {
                "distinct_range": 4,
                "num_eq": 1,
                "num_range": 4,
                "upper_bound": "355"
            },
            {
                "distinct_range": 4,
                "num_eq": 1,
                "num_range": 4,
                "upper_bound": "360"
            },
            {
                "distinct_range": 4,
                "num_eq": 1,
                "num_range": 4,
                "upper_bound": "365"
            },
            {
                "distinct_range": 4,
                "num_eq": 1,
                "num_range": 4,
                "upper_bound": "370"
            },
            {
                "distinct_range": 4,
                "num_eq": 1,
                "num_range": 4,
                "upper_bound": "375"
            },
            {
                "distinct_range": 4,
                "num_eq": 1,
                "num_range": 4,
                "upper_bound": "380"
            },
            {
                "distinct_range": 4,
                "num_eq": 1,
                "num_range": 4,
                "upper_bound": "385"
            },
            {
                "distinct_range": 4,
                "num_eq": 1,
                "num_range": 4,
                "upper_bound": "390"
            },
            {
                "distinct_range": 4,
                "num_eq": 1,
                "num_range": 4,
                "upper_bound": "395"
            },
            {
                "distinct_range": 4,
                "num_eq": 1,
                "num_range": 4,
                "upper_bound": "400"
            },
            {
                "distinct_range": 4,
                "num_eq": 1,
                "num_range": 4,
                "upper_bound": "405"
            },
            {
                "distinct_range": 4,
                "num_eq": 1,
                "num_range": 4,
                "upper_bound": "410"
            },
            {
                "distinct_range": 4,
                "num_eq": 1,
                "num_range": 4,
                "upper_bound": "415"
            },
            {
                "distinct_range": 4,
                "num_eq": 1,
                "num_range": 4,
                "upper_bound": "420"
            },
            {
                "distinct_range": 4,
                "num_eq": 1,
                "num_range": 4,
                "upper_bound": "425"
            },
            {
                "distinct_range": 4,
                "num_eq": 1,
                "num_range": 4,
                "upper_bound": "430"
            },
            {
                "distinct_range": 4,
                "num_eq": 1,
                "num_range": 4,
                "upper_bound": "435"
            },
            {
                "distinct_range": 4,
                "num_eq": 1,
                "num_range": 4,
                "upper_bound": "440"
            },
            {
                "distinct_range": 4,
                "num_eq": 1,
                "num_range": 4,
                "upper_bound": "445"
            },
            {
                "distinct_range": 4,
                "num_eq": 1,
                "num_range": 4,
                "upper_bound": "450"
            },
            {
                "distinct_range": 4,
                "num_eq": 1,
                "num_range": 4,
                "upper_bound": "455"
            },
            {
                "distinct_range": 4,
                "num_eq": 1,
                "num_range": 4,
                "upper_bound": "460"
            },
            {
                "distinct_range": 4,
                "num_eq": 1,
                "num_range": 4,
                "upper_bound": "465"
            },
            {
                "distinct_range": 4,
                "num_eq": 1,
                "num_range": 4,
                "upper_bound": "470"
            },
            {
                "distinct_range": 4,
                "num_eq": 1,
                "num_range": 4,
                "upper_bound": "475"
            },
            {
                "distinct_range": 4,
                "num_eq": 1,
                "num_range": 4,
                "upper_bound": "480"
            },
            {
                "distinct_range": 4,
                "num_eq": 1,
                "num_range": 4,
                "upper_bound": "485"
            },
            {
                "distinct_range": 4,
                "num_eq": 1,
                "num_range": 4,
                "upper_bound": "490"
            },
            {
                "distinct_range": 4,
                "num_eq": 1,
                "num_range": 4,
                "upper_bound": "495"
            },
            {
                "distinct_range": 4,
                "num_eq": 1,
                "num_range": 4,
                "upper_bound": "500"
            },
            {
                "distinct_range": 4,
                "num_eq": 1,
                "num_range": 4,
                "upper_bound": "505"
            },
            {
                "distinct_range": 4,
                "num_eq": 1,
                "num_range": 4,
                "upper_bound": "510"
            },
            {
                "distinct_range": 4,
                "num_eq": 1,
                "num_range": 4,
                "upper_bound": "515"
            },
            {
                "distinct_range": 4,
                "num_eq": 1,
                "num_range": 4,
                "upper_bound": "520"
            },
            {
                "distinct_range": 4,
                "num_eq": 1,
                "num_range": 4,
                "upper_bound": "525"
            },
            {
                "distinct_range": 4,
                "num_eq": 1,
                "num_range": 4,
                "upper_bound": "530"
            },
            {
                "distinct_range": 4,
                "num_eq": 1,
                "num_range": 4,
                "upper_bound": "535"
            },
            {
                "distinct_range": 4,
                "num_eq": 1,
                "num_range": 4,
                "upper_bound": "540"
            },
            {
                "distinct_range": 4,
                "num_eq": 1,
                "num_range": 4,
                "upper_bound": "545"
            },
            {
                "distinct_range": 4,
                "num_eq": 1,
                "num_range": 4,
                "upper_bound": "550"
            },
            {
                "distinct_range": 4,
                "num_eq": 1,
                "num_range": 4,
                "upper_bound": "555"
            },
            {
                "distinct_range": 4,
                "num_eq": 1,
                "num_range": 4,
                "upper_bound": "560"
            },
            {
                "distinct_range": 4,
                "num_eq": 1,
                "num_range": 4,
                "upper_bound": "565"
            },
            {
                "distinct_range": 4,
                "num_eq": 1,
                "num_range": 4,
                "upper_bound": "570"
            },
            {
                "distinct_range": 4,
                "num_eq": 1,
                "num_range": 4,
                "upper_bound": "575"
            },
            {
                "distinct_range": 4,
                "num_eq": 1,
                "num_range": 4,
                "upper_bound": "580"
            },
            {
                "distinct_range": 4,
                "num_eq": 1,
                "num_range": 4,
                "upper_bound": "585"
            },
            {
                "distinct_range": 4,
                "num_eq": 1,
                "num_range": 4,
                "upper_bound": "590"
            },
            {
                "distinct_range": 4,
                "num_eq": 1,
                "num_range": 4,
                "upper_bound": "595"
            },
            {
                "distinct_range": 4,
                "num_eq": 1,
                "num_range": 4,
                "upper_bound": "600"
            },
            {
                "distinct_range": 4,
                "num_eq": 1,
                "num_range": 4,
                "upper_bound": "605"
            },
            {
                "distinct_range": 4,
                "num_eq": 1,
                "num_range": 4,
                "upper_bound": "610"
            },
            {
                "distinct_range": 4,
                "num_eq": 1,
                "num_range": 4,
                "upper_bound": "615"
            },
            {
                "distinct_range": 4,
                "num_eq": 1,
                "num_range": 4,
                "upper_bound": "620"
            },
            {
                "distinct_range": 4,
                "num_eq": 1,
                "num_range": 4,
                "upper_bound": "625"
            },
            {
                "distinct_range": 4,
                "num_eq": 1,
                "num_range": 4,
                "upper_bound": "630"
            },
            {
                "distinct_range": 4,
                "num_eq": 1,
                "num_range": 4,
                "upper_bound": "635"
            },
            {
                "distinct_range": 4,
                "num_eq": 1,
                "num_range": 4,
                "upper_bound": "640"
            },
            {
                "distinct_range": 4,
                "num_eq": 1,
                "num_range": 4,
                "upper_bound": "645"
            },
            {
                "distinct_range": 4,
                "num_eq": 1,
                "num_range": 4,
                "upper_bound": "650"
            },
            {
                "distinct_range": 4,
                "num_eq": 1,
                "num_range": 4,
                "upper_bound": "655"
            },
            {
                "distinct_range": 4,
                "num_eq": 1,
                "num_range": 4,
                "upper_bound": "660"
            },
            {
                "distinct_range": 4,
                "num_eq": 1,
                "num_range": 4,
                "upper_bound": "665"
            },
            {
                "distinct_range": 4,
                "num_eq": 1,
                "num_range": 4,
                "upper_bound": "670"
            },
            {
                "distinct_range": 4,
                "num_eq": 1,
                "num_range": 4,
                "upper_bound": "675"
            },
            {
                "distinct_range": 4,
                "num_eq": 1,
                "num_range": 4,
                "upper_bound": "680"
            },
            {
                "distinct_range": 4,
                "num_eq": 1,
                "num_range": 4,
                "upper_bound": "685"
            },
            {
                "distinct_range": 4,
                "num_eq": 1,
                "num_range": 4,
                "upper_bound": "690"
            },
            {
                "distinct_range": 4,
                "num_eq": 1,
                "num_range": 4,
                "upper_bound": "695"
            },
            {
                "distinct_range": 4,
                "num_eq": 1,
                "num_range": 4,
                "upper_bound": "700"
            },
            {
                "distinct_range": 4,
                "num_eq": 1,
                "num_range": 4,
                "upper_bound": "705"
            },
            {
                "distinct_range": 4,
                "num_eq": 1,
                "num_range": 4,
                "upper_bound": "710"
            },
            {
                "distinct_range": 4,
                "num_eq": 1,
                "num_range": 4,
                "upper_bound": "715"
            },
            {
                "distinct_range": 4,
                "num_eq": 1,
                "num_range": 4,
                "upper_bound": "720"
            },
            {
                "distinct_range": 4,
                "num_eq": 1,
                "num_range": 4,
                "upper_bound": "725"
            },
            {
                "distinct_range": 4,
                "num_eq": 1,
                "num_range": 4,
                "upper_bound": "730"
            },
            {
                "distinct_range": 4,
                "num_eq": 1,
                "num_range": 4,
                "upper_bound": "735"
            },
            {
                "distinct_range": 4,
                "num_eq": 1,
                "num_range": 4,
                "upper_bound": "740"
            },
            {
                "distinct_range": 4,
                "num_eq": 1,
                "num_range": 4,
                "upper_bound": "745"
            },
            {
                "distinct_range": 4,
                "num_eq": 1,
                "num_range": 4,
                "upper_bound": "750"
            },
            {
                "distinct_range": 4,
                "num_eq": 1,
                "num_range": 4,
                "upper_bound": "755"
            },
            {
                "distinct_range": 4,
                "num_eq": 1,
                "num_range": 4,
                "upper_bound": "760"
            },
            {
                "distinct_range": 4,
                "num_eq": 1,
                "num_range": 4,
                "upper_bound": "765"
            },
            {
                "distinct_range": 4,
                "num_eq": 1,
                "num_range": 4,
                "upper_bound": "770"
            },
            {
                "distinct_range": 4,
                "num_eq": 1,
                "num_range": 4,
                "upper_bound": "775"
            },
            {
                "distinct_range": 4,
                "num_eq": 1,
                "num_range": 4,
                "upper_bound": "780"
            },
            {
                "distinct_range": 4,
                "num_eq": 1,
                "num_range": 4,
                "upper_bound": "785"
            },
            {
                "distinct_range": 4,
                "num_eq": 1,
                "num_range": 4,
                "upper_bound": "790"
            },
            {
                "distinct_range": 4,
                "num_eq": 1,
                "num_range": 4,
                "upper_bound": "795"
            },
            {
                "distinct_range": 4,
                "num_eq": 1,
                "num_range": 4,
                "upper_bound": "800"
            },
            {
                "distinct_range": 4,
                "num_eq": 1,
                "num_range": 4,
                "upper_bound": "805"
            },
            {
                "distinct_range": 4,
                "num_eq": 1,
                "num_range": 4,
                "upper_bound": "810"
            },
            {
                "distinct_range": 4,
                "num_eq": 1,
                "num_range": 4,
                "upper_bound": "815"
            },
            {
                "distinct_range": 4,
                "num_eq": 1,
                "num_range": 4,
                "upper_bound": "820"
            },
            {
                "distinct_range": 4,
                "num_eq": 1,
                "num_range": 4,
                "upper_bound": "825"
            },
            {
                "distinct_range": 4,
                "num_eq": 1,
                "num_range": 4,
                "upper_bound": "830"
            },
            {
                "distinct_range": 4,
                "num_eq": 1,
                "num_range": 4,
                "upper_bound": "835"
            },
            {
                "distinct_range": 4,
                "num_eq": 1,
                "num_range": 4,
                "upper_bound": "840"
            },
            {
                "distinct_range": 4,
                "num_eq": 1,
                "num_range": 4,
                "upper_bound": "845"
            },
            {
                "distinct_range": 4,
                "num_eq": 1,
                "num_range": 4,
                "upper_bound": "850"
            },
            {
                "distinct_range": 4,
                "num_eq": 1,
                "num_range": 4,
                "upper_bound": "855"
            },
            {
                "distinct_range": 4,
                "num_eq": 1,
                "num_range": 4,
                "upper_bound": "860"
            },
            {
                "distinct_range": 4,
                "num_eq": 1,
                "num_range": 4,
                "upper_bound": "865"
            },
            {
                "distinct_range": 4,
                "num_eq": 1,
                "num_range": 4,
                "upper_bound": "870"
            },
            {
                "distinct_range": 4,
                "num_eq": 1,
                "num_range": 4,
                "upper_bound": "875"
            },
            {
                "distinct_range": 4,
                "num_eq": 1,
                "num_range": 4,
                "upper_bound": "880"
            },
            {
                "distinct_range": 4,
                "num_eq": 1,
                "num_range": 4,
                "upper_bound": "885"
            },
            {
                "distinct_range": 4,
                "num_eq": 1,
                "num_range": 4,
                "upper_bound": "890"
            },
            {
                "distinct_range": 4,
                "num_eq": 1,
                "num_range": 4,
                "upper_bound": "895"
            },
            {
                "distinct_range": 4,
                "num_eq": 1,
                "num_range": 4,
                "upper_bound": "900"
            },
            {
                "distinct_range": 4,
                "num_eq": 1,
                "num_range": 4,
                "upper_bound": "905"
            },
            {
                "distinct_range": 4,
                "num_eq": 1,
                "num_range": 4,
                "upper_bound": "910"
            },
            {
                "distinct_range": 4,
                "num_eq": 1,
                "num_range": 4,
                "upper_bound": "915"
            },
            {
                "distinct_range": 4,
                "num_eq": 1,
                "num_range": 4,
                "upper_bound": "920"
            },
            {
                "distinct_range": 4,
                "num_eq": 1,
                "num_range": 4,
                "upper_bound": "925"
            },
            {
                "distinct_range": 4,
                "num_eq": 1,
                "num_range": 4,
                "upper_bound": "930"
            },
            {
                "distinct_range": 4,
                "num_eq": 1,
                "num_range": 4,
                "upper_bound": "935"
            },
            {
                "distinct_range": 4,
                "num_eq": 1,
                "num_range": 4,
                "upper_bound": "940"
            },
            {
                "distinct_range": 4,
                "num_eq": 1,
                "num_range": 4,
                "upper_bound": "945"
            },
            {
                "distinct_range": 4,
                "num_eq": 1,
                "num_range": 4,
                "upper_bound": "950"
            },
            {
                "distinct_range": 4,
                "num_eq": 1,
                "num_range": 4,
                "upper_bound": "955"
            },
            {
                "distinct_range": 4,
                "num_eq": 1,
                "num_range": 4,
                "upper_bound": "960"
            },
            {
                "distinct_range": 4,
                "num_eq": 1,
                "num_range": 4,
                "upper_bound": "965"
            },
            {
                "distinct_range": 4,
                "num_eq": 1,
                "num_range": 4,
                "upper_bound": "970"
            },
            {
                "distinct_range": 4,
                "num_eq": 1,
                "num_range": 4,
                "upper_bound": "975"
            },
            {
                "distinct_range": 5,
                "num_eq": 1,
                "num_range": 5,
                "upper_bound": "981"
            },
            {
                "distinct_range": 5,
                "num_eq": 1,
                "num_range": 5,
                "upper_bound": "987"
            },
            {
                "distinct_range": 5,
                "num_eq": 1,
                "num_range": 5,
                "upper_bound": "993"
            },
            {
                "distinct_range": 5,
                "num_eq": 1,
                "num_range": 5,
                "upper_bound": "999"
            }
        ],
        "histo_col_type": "INT8",
        "histo_version": 1,
        "name": "__auto__",
        "null_count": 0,
        "row_count": 1000
    },
    {
        "avg_size": 4,
        "columns": [
            "w_name"
        ],
        "created_at": "2022-06-15 01:45:57.80267",
        "distinct_count": 5,
        "histo_buckets": [
            {
                "distinct_range": 0,
                "num_eq": 192,
                "num_range": 0,
                "upper_bound": "10"
            },
            {
                "distinct_range": 3,
                "num_eq": 193,
                "num_range": 615,
                "upper_bound": "9"
            }
        ],
        "histo_col_type": "VARCHAR(10)",
        "histo_version": 1,
        "name": "__auto__",
        "null_count": 0,
        "row_count": 1000
    },
    {
        "avg_size": 4,
        "columns": [
            "w_street_1"
        ],
        "created_at": "2022-06-15 01:45:57.80267",
        "distinct_count": 11,
        "histo_buckets": [
            {
                "distinct_range": 0,
                "num_eq": 89,
                "num_range": 0,
                "upper_bound": "10"
            },
            {
                "distinct_range": 9,
                "num_eq": 101,
                "num_range": 810,
                "upper_bound": "20"
            }
        ],
        "histo_col_type": "VARCHAR(20)",
        "histo_version": 1,
        "name": "__auto__",
        "null_count": 0,
        "row_count": 1000
    },
    {
        "avg_size": 4,
        "columns": [
            "w_street_2"
        ],
        "created_at": "2022-06-15 01:45:57.80267",
        "distinct_count": 11,
        "histo_buckets": [
            {
                "distinct_range": 0,
                "num_eq": 90,
                "num_range": 0,
                "upper_bound": "10"
            },
            {
                "distinct_range": 9,
                "num_eq": 88,
                "num_range": 822,
                "upper_bound": "20"
            }
        ],
        "histo_col_type": "VARCHAR(20)",
        "histo_version": 1,
        "name": "__auto__",
        "null_count": 0,
        "row_count": 1000
    },
    {
        "avg_size": 4,
        "columns": [
            "w_city"
        ],
        "created_at": "2022-06-15 01:45:57.80267",
        "distinct_count": 11,
        "histo_buckets": [
            {
                "distinct_range": 0,
                "num_eq": 81,
                "num_range": 0,
                "upper_bound": "10"
            },
            {
                "distinct_range": 9,
                "num_eq": 104,
                "num_range": 815,
                "upper_bound": "20"
            }
        ],
        "histo_col_type": "VARCHAR(20)",
        "histo_version": 1,
        "name": "__auto__",
        "null_count": 0,
        "row_count": 1000
    },
    {
        "avg_size": 4,
        "columns": [
            "w_state"
        ],
        "created_at": "2022-06-15 01:45:57.80267",
        "distinct_count": 26,
        "histo_buckets": [
            {
                "distinct_range": 0,
                "num_eq": 41,
                "num_range": 0,
                "upper_bound": "AK"
            },
            {
                "distinct_range": 24,
                "num_eq": 38,
                "num_range": 921,
                "upper_bound": "ZT"
            }
        ],
        "histo_col_type": "CHAR(2)",
        "histo_version": 1,
        "name": "__auto__",
        "null_count": 0,
        "row_count": 1000
    },
    {
        "avg_size": 11,
        "columns": [
            "w_zip"
        ],
        "created_at": "2022-06-15 01:45:57.80267",
        "distinct_count": 10,
        "histo_buckets": [
            {
                "distinct_range": 0,
                "num_eq": 106,
                "num_range": 0,
                "upper_bound": "022311111"
            },
            {
                "distinct_range": 8,
                "num_eq": 99,
                "num_range": 795,
                "upper_bound": "902211111"
            }
        ],
        "histo_col_type": "CHAR(9)",
        "histo_version": 1,
        "name": "__auto__",
        "null_count": 0,
        "row_count": 1000
    },
    {
        "avg_size": 6,
        "columns": [
            "w_tax"
        ],
        "created_at": "2022-06-15 01:45:57.80267",
        "distinct_count": 771,
        "histo_buckets": [
            {
                "distinct_range": 0,
                "num_eq": 1,
                "num_range": 0,
                "upper_bound": "0"
            },
            {
                "distinct_range": 769,
                "num_eq": 2,
                "num_range": 997,
                "upper_bound": "0.1999"
            }
        ],
        "histo_col_type": "DECIMAL(4,4)",
        "histo_version": 1,
        "name": "__auto__",
        "null_count": 0,
        "row_count": 1000
    },
    {
        "avg_size": 8,
        "columns": [
            "w_ytd"
        ],
        "created_at": "2022-06-15 01:45:57.80267",
        "distinct_count": 1000,
        "histo_buckets": [
            {
                "distinct_range": 0,
                "num_eq": 1,
                "num_range": 0,
                "upper_bound": "5651274.29"
            },
            {
                "distinct_range": 998,
                "num_eq": 1,
                "num_range": 998,
                "upper_bound": "6231586.96"
            }
        ],
        "histo_col_type": "DECIMAL(12,2)",
        "histo_version": 1,
        "name": "__auto__",
        "null_count": 0,
        "row_count": 1000
    }
]';
